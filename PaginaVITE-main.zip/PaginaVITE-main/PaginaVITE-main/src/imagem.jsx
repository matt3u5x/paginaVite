import logo from "./assets/logo.jpg";

function Imagem() {
    return (
        <div className="imagem">
            <img src={logo} alt="Logo" />
        </div>
    );
}

export default Imagem;
